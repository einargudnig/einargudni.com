/**
 * @title Composing components, data and Layers
 *
 * Load a note with a `Query` and show it with child components. The
 * page handles a child's events, provides Layers with `Component.provide`,
 * makes one child swappable with `Feature.Service`, and passes its editor
 * into another component's slot. This entry module
 * mounts the page, which is in `fixtures/pages/notes/NotePage.ts`.
 */
import { BrowserHost } from "@effect/ui/html"
import { Effect, Layer } from "effect"
import { FetchHttpClient } from "effect/http"
// A page is one file under `pages/`, in the folder for its URL. It imports
// what it is composed from out of the features:
//
// - `fixtures/pages/notes/NotePage.ts`: the page, its query and its Layers
// - `fixtures/queries/GetNote.ts`: the `Query` the page shows
// - `fixtures/notes/components/NoteEditor.ts`: a child by value
// - `fixtures/notes/components/NoteActivity.ts`: a child by service
// - `fixtures/notes/components/ActivityLog.ts`: that service's implementation
// - `fixtures/kit/Collapsible.ts`: a component with slots, which the page
//   fills with markup of its own
import { NotePage } from "./fixtures/pages/notes/NotePage.ts"

// `NotePage` provides its query and feature Layers with
// `Component.provide`, and the editor inside it provides its own command.
// The plain name is always the component with its Layers provided, and
// `NotePageNoDeps` is the one without. Only the HTTP client is left for the
// entry module.
const Main = BrowserHost.mount(
  NotePage,
  { id: "welcome" },
  document.getElementById("app")!
).pipe(
  Layer.provide(FetchHttpClient.layer)
)

Layer.launch(Main).pipe(Effect.runFork)
