import { Component, UiSchema } from "@effect/ui"
import { Html, HtmlCommand } from "@effect/ui/html"
import { Schema } from "effect"

// `kit/` holds components that belong to no feature: a design system's
// behaviour, shared by every feature. A headless one owns the state, the
// keyboard and the ARIA, and has no markup. Each feature draws its own.

// The rows are data in props, as Schemas. A row carries what the Listbox
// needs to filter, step and announce it: an id, a label and whether it can be
// picked. Anything richer, such as a subtitle or an icon, stays with the
// consumer, which looks it up by id in its closure.
export const ListboxOption = Schema.Struct({
  id: Schema.String,
  label: Schema.String,
  disabled: Schema.optional(Schema.Boolean)
})
export type ListboxOption = typeof ListboxOption.Type

export const ListboxMessage = UiSchema.TaggedEnum({
  ToggledPopup: { open: Schema.Boolean },
  UpdatedQuery: { value: Schema.String },
  PressedKey: { key: Schema.String },
  ClickedOption: { id: Schema.String }
})

// What the consumer gets through `onEmit`. Typeahead on the closed trigger
// picks too, as a native `<select>` does.
export const ListboxEvents = UiSchema.TaggedEnum({
  Picked: { id: Schema.String }
})

// Refs into the consumer's elements. A part attaches them, so they belong to
// the Listbox and its `update` can focus and scroll them. `Row.at(id)`
// names one row.
const Trigger = Html.ref("Listbox.trigger", "button")
const Input = Html.ref("Listbox.input", "input")
const Row = Html.ref("Listbox.option", "li")

const filter = (options: ReadonlyArray<ListboxOption>, query: string) =>
  query === ""
    ? options
    : options.filter((o) => o.label.toLowerCase().includes(query.toLowerCase()))

// The next enabled row after `from`, wrapping, or the first or last one.
const step = (
  options: ReadonlyArray<ListboxOption>,
  from: string | null,
  direction: 1 | -1
): string | null => {
  const enabled = options.filter((o) => o.disabled !== true)
  if (enabled.length === 0) return null
  const index = enabled.findIndex((o) => o.id === from)
  if (index < 0) {
    return direction === 1
      ? enabled[0]!.id
      : enabled[enabled.length - 1]!.id
  }
  return enabled[(index + direction + enabled.length) % enabled.length]!.id
}

// The Model keeps an id into the props' rows, and the consumer can replace
// them at any time, so every reader goes through this: the active row, if
// it's still shown and can be picked.
const activeIn = (shown: ReadonlyArray<ListboxOption>, active: string | null) =>
  shown.some((o) => o.id === active && o.disabled !== true) ? active : null

// `HtmlCommand.focus` and `HtmlCommand.scrollIntoView` act on the element a
// ref from `Html.ref` names, once the render is committed, and report
// whether the ref was rendered. Nothing here depends on it, so they end in
// `Component.noop`, which sends nothing, and the Message union has no no-op
// variant.
const silent = () => Component.noop

/**
 * A trigger that opens a popup with a filter input and the rows. The input is
 * an ARIA combobox and the rows are its listbox, as in a command palette.
 * Typeahead runs on the trigger, and arrows, Enter and Escape on the input:
 * keys are handled on the element that has focus. A key handler on the popup
 * around them would also catch keys meant for the consumer's own controls.
 */
export const Listbox = Html.component({
  name: "Listbox",

  props: Schema.Struct({
    options: Schema.Array(ListboxOption),
    // The consumer owns the value. The Listbox reads it to start from it.
    selected: Schema.NullOr(Schema.String)
  }),

  model: Schema.Struct({
    open: Schema.Boolean,
    query: Schema.String,
    active: Schema.NullOr(Schema.String),
    typed: Schema.String
  }),

  message: ListboxMessage,
  events: ListboxEvents
}).make({
  init: () => ({ open: false, query: "", active: null, typed: "" }),
  update: ($, message) =>
    ListboxMessage.match(message, {
      // The popup is an auto popover. The browser opens it from the trigger
      // and closes it on Escape or a click outside, and the Model follows.
      // Focus moves into the popup and back to the trigger with it.
      ToggledPopup: ({ open }) =>
        $.evolve({ open, query: "", active: open ? $.props.selected : null })
          .run(
            open
              ? HtmlCommand.focus(Input, silent)
              : HtmlCommand.focus(Trigger, silent)
          ),
      UpdatedQuery: ({ value }) =>
        $.evolve({
          query: value,
          active: step(filter($.props.options, value), null, 1)
        }),
      PressedKey: ({ key }) => {
        const shown = filter($.props.options, $.model.query)
        const active = activeIn(shown, $.model.active)
        switch (key) {
          case "ArrowDown":
          case "ArrowUp": {
            const next = step(shown, active, key === "ArrowDown" ? 1 : -1)
            // `aria-activedescendant` leaves focus in the input, so the
            // browser doesn't scroll the active row into view by itself.
            return next === null
              ? $.evolve({ open: true })
              : $.evolve({ open: true, active: next })
                .run(
                  HtmlCommand.scrollIntoView(Row.at(next), silent, {
                    block: "nearest"
                  })
                )
          }
          case "Enter":
            return active === null
              ? $.model
              : $.evolve({ open: false }).emit(
                ListboxEvents.Picked({ id: active })
              )
          case "Escape":
            return $.evolve({ open: false })
          default: {
            // Typeahead: the first label starting with what was typed. A key
            // no label continues with starts over from that key, so `typed`
            // is never longer than a label and needs no timer to reset it.
            const find = (prefix: string) =>
              $.props.options.find((o) =>
                o.disabled !== true && o.label.toLowerCase().startsWith(prefix)
              )
            const extended = $.model.typed + key.toLowerCase()
            const typed = find(extended) !== undefined
              ? extended
              : key.toLowerCase()
            const hit = find(typed)
            return hit === undefined
              ? $.evolve({ typed: "" })
              : $.evolve({ typed }).emit(ListboxEvents.Picked({ id: hit.id }))
          }
        }
      },
      ClickedOption: ({ id }) =>
        activeIn($.props.options, id) === null
          ? $.model
          : $.evolve({ open: false }).emit(ListboxEvents.Picked({ id }))
    }),
  // `parts` returns plain values for the consumer to read, and parts to
  // apply to its elements. `p.part(tag, decorate)` takes only a builder of
  // that tag, checked in the types and when it's applied. A part adds ARIA,
  // ids, refs and handlers, and the consumer adds everything else.
  //
  // `p.id` is derived from the instance's path, so two Listboxes on a page
  // never share an id, and the server and the browser agree on them.
  //
  // Parts need no runtime. A test of the Listbox builds them from a Model and
  // props with `Story.parts(Listbox, { model, props })`, and `Scene.make`
  // runs it with a stand-in view for the consumer.
  parts: (p, model) => {
    const shown = filter(p.props.options, model.query)
    const active = activeIn(shown, model.active)
    return {
      open: model.open,
      shown,
      active,
      trigger: p.part("button", (b) =>
        b.ref(Trigger)
          .attrs({
            type: "button",
            "aria-haspopup": "dialog",
            "aria-expanded": String(model.open),
            "aria-controls": p.id("popup"),
            // A `popovertarget` invoker: the browser toggles the popup, and a
            // click on the trigger while it's open closes it.
            popovertarget: p.id("popup")
          })
          .on(
            "keydown",
            ({ alt, ctrl, key, meta }) =>
              key === "ArrowDown" ||
                (key.length === 1 && key !== " " && !alt && !ctrl && !meta)
                ? ListboxMessage.PressedKey({ key })
                : undefined,
            // Cancels the default only when a message was returned, so Tab,
            // Space and Enter keep working.
            { preventDefault: true }
          )),
      popup: p.part("div", (b) =>
        b.id(p.id("popup"))
          .attr("role", "dialog")
          .popover("auto", model.open)
          .on("toggle", ({ open }) => ListboxMessage.ToggledPopup({ open }))),
      input: p.part("input", (b) =>
        b.ref(Input)
          .attrs({
            role: "combobox",
            "aria-autocomplete": "list",
            "aria-expanded": "true",
            "aria-controls": p.id("list"),
            "aria-activedescendant": active === null
              ? undefined
              : p.id("option", active)
          })
          .value(model.query)
          .on("input", ({ value }) => ListboxMessage.UpdatedQuery({ value }))
          .on("keydown", ({ key }) =>
            key === "ArrowDown" || key === "ArrowUp" || key === "Enter" ||
              key === "Escape"
              ? ListboxMessage.PressedKey({ key })
              : undefined, { preventDefault: true })),
      list: p.part("ul", (b) => b.id(p.id("list")).attr("role", "listbox")),
      // A part takes arguments after the builder: the consumer passes the
      // row it's drawing.
      option: p.part(
        "li",
        (b, option: ListboxOption) =>
          b.id(p.id("option", option.id))
            .ref(Row.at(option.id))
            .attrs({
              role: "option",
              "aria-selected": String(active === option.id),
              "aria-disabled": option.disabled === true ? "true" : undefined
            })
            .on(
              "click",
              option.disabled === true
                ? () => undefined
                : ListboxMessage.ClickedOption({ id: option.id })
            )
      )
    }
  }
})
