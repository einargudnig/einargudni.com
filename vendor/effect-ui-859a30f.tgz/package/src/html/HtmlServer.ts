/**
 * Server rendering for `@effect/ui`: renders a component tree to HTML that
 * `HtmlHydrate.hydrate` hydrates.
 *
 * `renderToHtml` builds provided Layers and fetches query data once per key
 * in a per-request cache. Rendering waits until nothing is in flight or the
 * `budget` is spent, then serialises once. No Command runs on the server.
 * Only query-watch Subscriptions run; other Subscriptions and `onMount`
 * work wait for the client.
 *
 * The result holds the body markup, the `state` the client adopts, with the
 * query entries that settled, the root's Model (for the response status),
 * and the document head as escaped strings. The page puts them together;
 * `serializeState` makes the state safe to embed in a `<script>`.
 *
 * Set the budget to what your page's data needs, or 0 for no waiting. A
 * budget miss renders the loading Model, with its title, and the client
 * fetches what missed it.
 *
 * **Example** (Rendering a page)
 *
 * ```ts
 * import { Html, HtmlHead, HtmlServer } from "@effect/ui/html"
 * import { Effect, Schema } from "effect"
 * import { Head } from "@effect/ui"
 *
 * const App = Html.component({
 *   name: "App",
 *   model: Schema.Struct({}),
 *   message: Schema.Never
 * }).make({
 *   init: () => ({}),
 *   update: ($) => $.model,
 *   head: () => [Head.title("Home"), HtmlHead.lang("en")],
 *   view: (h) => h.h1("Home")
 * })
 *
 * const page = Effect.gen(function*() {
 *   const { bodyAttributes, head, html, htmlAttributes, state } = yield* HtmlServer.renderToHtml(App, {})
 *   return `<!doctype html>
 * <html ${htmlAttributes}>
 *   <head><meta charset="utf-8">${head}</head>
 *   <body ${bodyAttributes}>
 *     <div id="app">${html}</div>
 *     <script type="application/json" id="state">${HtmlServer.serializeState(state)}</script>
 *   </body>
 * </html>`
 * })
 * ```
 *
 * On the client, hydrate the same component with the same props and the
 * parsed state: `HtmlHydrate.hydrate(App, {}, container, state)`, or
 * `HtmlHydrate.hydrateEffect` to wait for `root.adopted`.
 *
 * A routed app served through `HttpRouter` uses `layerHttp` from
 * `@effect/ui/html/HtmlServerHttp` instead: it resolves each request's URL,
 * answers 404s and redirects, and renders the page with
 * `Router.props(routes)` as the props.
 *
 * @stability experimental
 * @since 0.1.0
 */
import type * as Context from "effect/Context"
import type * as Duration from "effect/Duration"
import * as Effect from "effect/Effect"
import type * as Component from "../Component.ts"
import * as runtime from "../internal/runtime.ts"
import type * as Renderer from "../Renderer.ts"
import type * as View from "../View.ts"
import type * as BrowserHost from "./BrowserHost.ts"
import * as Html from "./Html.ts"
import * as server from "./internal/server.ts"

/**
 * What `renderToHtml` returns.
 *
 * **Details**
 *
 * `html` is the body markup for the app's container. `state` maps each
 * instance's path to its Schema-encoded Model, plus `~deferred`, the
 * settled query entries under `~query`, the last message each owner of
 * shared state got from its reports under `~reported`, and `~static` for a
 * static render;
 * pass it to `BrowserHost.mount`. `model` is the root's Model
 * after the server run, for app code that sets the status (a 404 for a
 * missing record), or `undefined` if the root failed. `head` holds the
 * `<title>`, meta, link and JSON-LD tags, and `htmlAttributes` and
 * `bodyAttributes` the attributes for `<html ${htmlAttributes}>` and
 * `<body ${bodyAttributes}>`. All of them are escaped.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Rendered<out Model> {
  readonly html: string
  readonly state: Renderer.State
  readonly model: Model | undefined
  readonly head: string
  readonly htmlAttributes: string
  readonly bodyAttributes: string
}

/** Element operations on the server, where there are no elements to reach. */
const serverHtmlHost: Context.Service.Shape<typeof Html.Host> = {
  focus: () => {},
  blur: () => {},
  scrollIntoView: () => {},
  measure: () => ({
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }),
  select: () => {},
  requestSubmit: () => false,
  showPicker: () => false
}

/**
 * Renders a component tree to HTML, with the state the client adopts.
 *
 * **When to use**
 *
 * Use when the render needs services that belong to the request, such as
 * the current user, or when the server doesn't use `HttpRouter`. Provide
 * those services to the returned Effect per request.
 *
 * **Details**
 *
 * It needs the tree's requirements, as `BrowserHost.mount` does, and runs
 * in its own Scope. The root must render HTML or be host-neutral. Give a
 * `MessageLog` Layer to log the server run; its entries stay on the server.
 *
 * `budget` (default 500 ms) is one deadline for the whole render. It limits
 * waiting on provided Layers and fetches, not the render. A Layer that misses
 * it, or that `Component.provide(..., { server: false })` keeps off the
 * server, renders its feature children's `fallback`, and the client builds
 * that instance fresh. A fetch that misses it isn't shipped, and the client
 * fetches it after hydration. A defect renders the child's `fallback`, and
 * the client builds the child fresh.
 *
 * `props` may be an Effect, such as `Router.props(AppRoute)` under
 * `Router.static`, run once before `init`. Its requirements are added to the
 * render's. The client resolves its own props the same way, from its Router.
 *
 * `static: true` is for HTML built at deploy or held in a CDN, where the
 * data's age is unknown. The client then hydrates every entry stale: it is
 * invalidated at hydration, and refetched once, unless its query's
 * `staleTime` is `"Infinity"`. There is no fetch-free window. A page
 * prerendered without search params, such as `/search`, may be served for
 * `/search?q=x`, and a 404 prerendered at `/404` for any unknown path:
 * `Router.subscription` then delivers the Router's route without reporting
 * `RouteMismatch`. The default is HTML rendered per request, whose entries
 * hydrate fresh.
 *
 * **Gotchas**
 *
 * Read data is public: `state` includes every settled entry, including typed
 * Failures and entries no view renders.
 *
 * Route status is the app's: resolve the URL with `AppRoute.resolve` first,
 * answer a `notFound` route with a 404, a `redirected` one with a
 * permanent redirect, and one with `invalid` search keys with a temporary
 * one, even when it's also `redirected`. `HtmlServerHttp.layerHttp` does
 * this for an app served through `HttpRouter`.
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const renderToHtml = <
  Name extends string,
  Props,
  Model,
  Msg,
  Events,
  R,
  V extends View.Elements,
  RP = never
>(
  component:
    & Component.Members<Name, Props, Model, Msg, Events, R, V, any>
    & BrowserHost.HtmlRoot<V>,
  props: Props | Effect.Effect<Props, never, RP>,
  options?: {
    readonly budget?: Duration.Input | undefined
    readonly static?: boolean | undefined
  }
): Effect.Effect<Rendered<Model>, never, Exclude<R | RP, Html.Host>> =>
  Effect.suspend(() => {
    const writer = server.makeWriter()
    // `Renderer.prerender`, with the writer as the tree's sink.
    return runtime.prerender(component as any, props, {
      budget: options?.budget ?? "500 millis",
      elements: [Html.name],
      static: options?.static,
      sink: writer
    }).pipe(
      Effect.provideService(Html.Host, serverHtmlHost),
      Effect.map((rendered) => {
        const head = server.htmlHead(rendered.head)
        return {
          // Written here, after the render's Scope has closed.
          html: writer.html(),
          state: rendered.state,
          model: rendered.model,
          head: server.headTags(head),
          htmlAttributes: server.attributes(server.htmlOwned(head)),
          bodyAttributes: server.attributes(server.bodyOwned(head))
        }
      })
    )
  }) as any

/**
 * The state as JSON that is safe inside `<script type="application/json">`:
 * `<` and the line separators are escaped, so the script can't end early.
 *
 * @stability experimental
 * @category utils
 * @since 0.1.0
 */
export const serializeState = (state: Renderer.State): string =>
  JSON.stringify(state).replace(
    /[<\u2028\u2029]/g,
    (char) => `\\u${char.charCodeAt(0).toString(16).padStart(4, "0")}`
  )

/**
 * Fills an HTML template with a rendered page.
 *
 * **When to use**
 *
 * Use with an `index.html` that holds the page's static markup and asset
 * tags. `HtmlServerVite.plugin` does this with the app's own `index.html`.
 *
 * **Details**
 *
 * It adds `htmlAttributes` and `bodyAttributes` right after the `<html>`
 * and `<body>` tag names, puts `head` before `</head>`, replaces the
 * `<!--app-html-->` marker with `html`, and adds the state as
 * `<script type="application/json" id="state">` before `</body>`.
 *
 * **Gotchas**
 *
 * It throws if the template has no `<!--app-html-->`, `</head>` or
 * `</body>`. Leave attributes the app sets through its head, such as
 * `lang`, out of the template, or the tag gets them twice.
 *
 * **Example** (Filling a template)
 *
 * ```ts import.meta.vitest
 * import { HtmlServer } from "@effect/ui/html"
 *
 * const template =
 *   "<html><head></head><body><div id=\"app\"><!--app-html--></div></body></html>"
 *
 * const page = HtmlServer.document(template, {
 *   html: "<h1>Home</h1>",
 *   state: {},
 *   model: undefined,
 *   head: "<title>Home</title>",
 *   htmlAttributes: "lang=\"en\"",
 *   bodyAttributes: ""
 * })
 * page // => '<html lang="en"><head><title>Home</title></head><body><div id="app"><h1>Home</h1></div><script type="application/json" id="state">{}</script></body></html>'
 * ```
 *
 * @stability experimental
 * @category utils
 * @since 0.1.0
 */
export const document = (
  template: string,
  rendered: Rendered<unknown>
): string => {
  if (!template.includes(appMarker)) {
    throw new Error(`The document template has no ${appMarker} marker`)
  }
  let html = withAttributes(
    template,
    /<html(?=[\s/>])/i,
    rendered.htmlAttributes
  )
  html = withAttributes(html, /<body(?=[\s/>])/i, rendered.bodyAttributes)
  html = insertBefore(html, "</head>", rendered.head)
  html = insertBefore(
    html,
    "</body>",
    `<script type="application/json" id="state">${
      serializeState(rendered.state)
    }</script>`
  )
  // Last, so no search above runs over the app's markup.
  return html.replace(appMarker, () => rendered.html)
}

const appMarker = "<!--app-html-->"

const withAttributes = (html: string, open: RegExp, attributes: string) =>
  attributes === ""
    ? html
    : html.replace(open, (tag) => `${tag} ${attributes}`)

const insertBefore = (html: string, tag: string, content: string) => {
  const index = html.indexOf(tag)
  if (index === -1) {
    throw new Error(`The document template has no ${tag}`)
  }
  return html.slice(0, index) + content + html.slice(index)
}
