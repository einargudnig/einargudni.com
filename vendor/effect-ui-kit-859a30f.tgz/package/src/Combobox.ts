/**
 * An input that filters a list of options as the user types, and picks one
 * or more of them.
 *
 * `Combobox` is headless: it owns the keyboard and pointer behaviour, the
 * filtering, focus, placement, the data attributes and the form inputs, and
 * the consumer draws the markup. The consumer owns whether the popup is
 * open, what's selected and the input's text, passes them as `open`,
 * `value` and `inputValue`, and stores what the `RequestedOpen`,
 * `RequestedClose`, `Picked` and `RequestedInputValue` events ask for.
 * Values are strings, and `items` lists every option with its label. The
 * combobox filters them and hands back `combobox.items`, the ones to draw.
 *
 * **Anatomy**
 *
 * | Part            | Element                                                   |
 * | :-------------- | :-------------------------------------------------------- |
 * | `inputGroup`    | `<div>` around the input and its buttons, the anchor    |
 * | `input`         | `<input>`, the combobox                                  |
 * | `trigger`       | `<button>` that toggles the popup                        |
 * | `icon`          | `<span>` inside the trigger                              |
 * | `clear`         | `<button>` that clears the text and the value            |
 * | `chips`         | `<div>` around the chips and the input, with `multiple` |
 * | `chip`          | `<div>`, one per selected value                          |
 * | `chipRemove`    | `<button>` inside a chip                                 |
 * | `label`         | `<div>` that names the input, the list and the popup  |
 * | `value`         | `<span>` inside the trigger, with `inputInPopup`        |
 * | `backdrop`      | `<div>`, a manual popover under the positioner           |
 * | `positioner`    | `<div>`, a manual popover placed by the combobox         |
 * | `popup`         | `<div>` inside the positioner                            |
 * | `arrow`         | `<div>` inside the popup                                 |
 * | `list`          | `<div>` around the items                                 |
 * | `row`           | `<div>` around a row of items, with `grid`              |
 * | `item`          | `<div>`, one per drawn value, inside the list            |
 * | `itemIndicator` | `<span>` inside an item, shown while it's selected       |
 * | `group`         | `<div>` around items                                     |
 * | `groupLabel`    | `<div>` inside a group                                   |
 * | `separator`     | `<div>` between items                                    |
 * | `empty`         | `<div>`, its children drawn while no item matches        |
 * | `status`        | `<div>`, a live region for a message such as a count     |
 * | `finalFocus`    | any focusable element, focused on close                   |
 *
 * Each part takes the consumer's builder and returns it with the part
 * applied, and the consumer adds the children. `item`, `itemIndicator`,
 * `chip` and `chipRemove` take an options object, `{ element, value }`,
 * and `group` and `groupLabel` take `{ element, group }`, where `group` is
 * the `group` of the items inside. `clear` takes `{ element }`. `item` and
 * `chip` key their element with the value. `clear` and `itemIndicator`
 * return `undefined` while they're hidden; a `keepMounted` field keeps
 * them drawn. `empty` drops its children while the list has items, so the
 * live region stays in the page.
 *
 * Draw `combobox.items`, not `items`: it's the filtered list, which keeps
 * its contents while the popup animates out. `combobox.groups` splits it
 * by each item's `group`, dropping groups with nothing left, and each
 * group's `rows` splits it again by `row`, for `grid`. Every value drawn
 * with `item` has to be in `items` or `filteredItems`.
 *
 * Focus stays in the input: the highlighted item is named by
 * `aria-activedescendant`, and presses on the trigger, the clear button,
 * the chips and the items don't take focus. In a `Field`, draw it as
 * `combobox.input(field.control(h.input))` and name it with `field.label`.
 *
 * With `inputInPopup`, the trigger is the combobox and shows the selected
 * label in `value`, the popup is a dialog, and opening moves focus to the
 * input inside it. Name the trigger with `label`.
 *
 * With `inline`, the list is drawn without a popup, as in a command
 * palette: it's always expanded, and the arrow keys move through it while
 * `open` is false.
 *
 * The positioner is a manual popover, so it renders in the top layer and
 * needs no portal. The browser gives a popover a border, padding, a
 * background and `overflow: auto`, so reset those on the positioner and
 * the backdrop and style the popup instead.
 *
 * With `topLayer: false`, the backdrop and the positioner render in place
 * as ordinary elements, `hidden` while closed, and the popup is placed and
 * clipped inside its containing block, as `Positioning` describes. The
 * backdrop covers that block, and the combobox is never modal.
 *
 * **CSS variables**
 *
 * Set on the positioner:
 *
 * - `--anchor-width`, `--anchor-height`: the anchor's size
 * - `--available-width`, `--available-height`: the space between the
 *   anchor and the edge of the collision boundary, for a `max-height`
 *
 * Set on the popup: `--transform-origin`, the point the popup grows from.
 *
 * **Data attributes**
 *
 * Each present with an empty value or absent, except `data-side`,
 * `data-align`, `data-popup-side` and `data-orientation`, which hold a
 * value:
 *
 * - `input`: `data-popup-open`, `data-pressed`, `data-popup-side`,
 *   `data-list-empty`, `data-disabled`, `data-readonly`,
 *   `data-required`
 * - `inputGroup`: as on the input, without `data-required`, and with
 *   `data-placeholder`
 * - `trigger`: as on the input, and `data-placeholder`
 * - `icon`: `data-popup-open`
 * - `clear`: `data-popup-open`, `data-disabled`, `data-visible`
 * - `value`: `data-placeholder`
 * - `chip`, `chipRemove`: `data-disabled`
 * - `backdrop`: `data-open` / `data-closed`, `data-starting-style`,
 *   `data-ending-style`
 * - `positioner`: as on the backdrop, and `data-side`, `data-align`,
 *   `data-anchor-hidden`, `data-empty`
 * - `popup`: as on the positioner
 * - `arrow`: as on the backdrop, and `data-side`, `data-align`,
 *   `data-uncentered`
 * - `list`: `data-empty`
 * - `item`: `data-selected`, `data-highlighted`, `data-disabled`
 * - `separator`: `data-orientation`
 *
 * **Keyboard**
 *
 * In the input, ArrowDown and ArrowUp open the popup on the selected item,
 * or on the first or, for ArrowUp, the last item, and then move the
 * highlight. Past either end the highlight leaves the list, and the next
 * press wraps around; with `loopFocus: false` it stops at the ends. Enter
 * picks the highlighted item, and with nothing highlighted it closes the
 * popup on its keyup, leaving the keydown to submit a form. Space picks the
 * highlighted item while the input is empty. Escape closes the popup, and
 * on a closed combobox clears the text and the value. Typing opens the
 * popup. Keys pressed while an IME composes text are left alone.
 *
 * With `grid`, ArrowLeft and ArrowRight move between the items of a row
 * once one is highlighted. With chips, ArrowLeft with the caret at the
 * start of the input moves focus to the last chip, and Backspace in an
 * empty input removes the last value. On a chip, ArrowLeft and ArrowRight
 * move between chips and back to the input, Backspace and Delete remove
 * it, and Enter, Space, a letter, ArrowDown and ArrowUp return to the
 * input, the arrows opening the popup. The horizontal arrows follow
 * `dir` or, without it, the nearest `DirectionProvider` above the
 * combobox or, without one, the CSS `direction` of the chips for the
 * chip keys, and of the popup or an inline list for the item keys.
 *
 * With `inputInPopup`, ArrowDown and ArrowUp on the trigger open the
 * popup, and typing a letter on the closed trigger selects the next
 * matching item without opening.
 *
 * **Form**
 *
 * With `name`, `required` or `autoComplete`, the input, or the trigger
 * with `inputInPopup`, is wrapped in a `display: contents` span that
 * holds a visually hidden input, so `required` blocks a form's submission,
 * the browser can autofill it, and the value is submitted. Autofill picks
 * the item whose value, then whose label, matches. A `multiple` combobox
 * submits one hidden input per value. An empty string counts as no value.
 *
 * **Limits**
 *
 * Props can't hold functions, so `filter` names a matcher and a consumer
 * with its own filter passes the result as `filteredItems`, or sets
 * `filter: "none"` and filters the `items` it passes, as for results
 * fetched while typing. `makeComboboxFilter` gives the combobox's matchers
 * to a consumer's own filter. There are no `default*` props or refs, no
 * portal, and items are `{ value, label }` rather than any object.
 *
 * **Example** (A fruit picker in a field, with the open state, the value and the text in the consumer's Model)
 *
 * ```ts import.meta.vitest
 * import { UiSchema } from "@effect/ui"
 * import { Html, HtmlServer } from "@effect/ui/html"
 * import { Combobox, Field } from "@effect/ui-kit"
 * import { Effect, Schema } from "effect"
 *
 * const fruits = [
 *   { value: "apple", label: "Apple" },
 *   { value: "banana", label: "Banana" },
 *   { value: "grape", label: "Grape" }
 * ]
 *
 * const PickerMessage = UiSchema.TaggedEnum({
 *   RequestedOpenFruit: {},
 *   RequestedCloseFruit: {},
 *   PickedFruit: { fruit: Schema.NullOr(Schema.String) },
 *   RequestedInputValueFruit: { text: Schema.String }
 * })
 *
 * const Picker = Html.component({
 *   name: "Picker",
 *   model: Schema.Struct({ open: Schema.Boolean, fruit: Schema.NullOr(Schema.String), text: Schema.String }),
 *   message: PickerMessage
 * }).make({
 *   init: () => ({ open: false, fruit: "banana", text: "Banana" }),
 *   update: {
 *     RequestedOpenFruit: ($) => $.evolve({ open: true }),
 *     RequestedCloseFruit: ($) => $.evolve({ open: false }),
 *     PickedFruit: ($, { fruit }) => $.evolve({ fruit }),
 *     RequestedInputValueFruit: ($, { text }) => $.evolve({ text })
 *   },
 *   view: (h, model) =>
 *     Field(h, {
 *       props: { filled: model.fruit !== null },
 *       view: (field) =>
 *         Combobox(h, {
 *           props: {
 *             open: model.open,
 *             value: model.fruit,
 *             inputValue: model.text,
 *             items: fruits,
 *             name: "fruit",
 *             disabled: field.disabled
 *           },
 *           onEmit: {
 *             RequestedOpen: () => PickerMessage.RequestedOpenFruit(),
 *             RequestedClose: () => PickerMessage.RequestedCloseFruit(),
 *             Picked: ({ value }) => PickerMessage.PickedFruit({ fruit: typeof value === "string" ? value : null }),
 *             RequestedInputValue: ({ inputValue }) => PickerMessage.RequestedInputValueFruit({ text: inputValue }),
 *             Highlighted: () => undefined,
 *             Settled: () => undefined
 *           },
 *           view: (combobox) =>
 *             field.root(h.div).children(
 *               field.label(h.label).children("Fruit"),
 *               combobox.inputGroup(h.div).children(
 *                 combobox.input(field.control(h.input)),
 *                 combobox.clear({ element: h.button })?.children("×"),
 *                 combobox.trigger(h.button).children(combobox.icon(h.span).children("▾"))
 *               ),
 *               combobox.positioner(h.div).children(
 *                 combobox.popup(h.div).children(
 *                   combobox.empty(h.div).children("No fruit found"),
 *                   combobox.list(h.div).children(
 *                     combobox.items.map(({ label, value }) =>
 *                       combobox.item({ element: h.div, value }).children(
 *                         label,
 *                         combobox.itemIndicator({ element: h.span, value })?.children("✓")
 *                       )
 *                     )
 *                   )
 *                 )
 *               )
 *             )
 *         })
 *     })
 * })
 *
 * // The input is a combobox that shows the selected fruit.
 * const { html } = await Effect.runPromise(HtmlServer.renderToHtml(Picker, {}))
 * if (!/<input[^>]* role="combobox"/.test(html) || !/<input[^>]* value="Banana"/.test(html)) {
 *   throw new Error("the input doesn't show the fruit")
 * }
 * ```
 *
 * @stability experimental
 * @since 0.1.0
 */
import * as Html from "@effect/ui/html/Html"
import * as UiSchema from "@effect/ui/UiSchema"
import * as Schema from "effect/Schema"
import { DirectionProvider } from "./DirectionProvider.ts"
import * as Engine from "./internal/combobox.ts"
import { type TextFilter, textFilter } from "./internal/filter.ts"
import { valueSchema } from "./internal/formInputs.ts"
import * as Positioning from "./Positioning.ts"

/**
 * One option of a `Combobox`.
 *
 * **Details**
 *
 * - `value`: what's selected and submitted. Unique among the items.
 * - `label`: the text matched while filtering, put in the input when the
 *   item is picked, and shown in the `value` part.
 * - `disabled`: the item can be highlighted but not picked.
 * - `group`: the key of the group it's drawn in, for `combobox.groups`.
 * - `row`: the row it's drawn in, for `grid`. Neighbouring items of a group
 *   with the same `row` share a row.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxItem = Engine.Item

/**
 * One option of a `Combobox`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxItem<V extends string = string> = Engine.Item<V>

/**
 * What a `Combobox` holds: the selected value, the values with
 * `multiple`, or `null` for none.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxValue = valueSchema(Schema.String)

/**
 * What a `Combobox` holds.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxValue<V extends string = string> = ReturnType<
  typeof valueSchema<Schema.Codec<V, string>>
>["Type"]

/**
 * How the combobox was opened or closed: `"keyboard"` for a key or a
 * click from no pointer.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxInteraction = Engine.Interaction

/**
 * How the combobox was opened or closed.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxInteraction = typeof ComboboxInteraction.Type

/**
 * Why a `Combobox` asks to open, close or change its value or its text.
 *
 * **Details**
 *
 * - `"trigger-press"`: a press on the trigger
 * - `"input-press"`: a press on the input or the input group
 * - `"outside-press"`: a press outside the combobox and the popup, other
 *   than on a scrollbar
 * - `"item-press"`: an item was picked, with the pointer or the keyboard
 * - `"close-press"`: the visually hidden dismiss button in the popup, for
 *   screen readers
 * - `"escape-key"`: Escape in the input
 * - `"list-navigation"`: ArrowDown or ArrowUp opened the popup
 * - `"focus-out"`: focus left the combobox and the popup
 * - `"input-change"`: the user edited the input's text
 * - `"input-clear"`: the combobox cleared the text, or the user emptied
 *   it, which clears a single value
 * - `"clear-press"`: the clear button
 * - `"chip-remove-press"`: a chip's remove button
 * - `"cancel-open"`: the press that opened it was released away from the
 *   trigger and the popup
 * - `"none"`: anything else, such as typeahead on the trigger, autofill,
 *   Backspace removing a chip, or the selected label put back in the input
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxChangeReason = Engine.ChangeReason

/**
 * Why a `Combobox` asks to open, close or change its value or its text.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxChangeReason = typeof ComboboxChangeReason.Type

/**
 * What moved the highlight: `"keyboard"`, `"pointer"`, or
 * `"none"` for the combobox itself, as when it opens or the list
 * changes.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxHighlightReason = Engine.HighlightReason

/**
 * What moved the highlight.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxHighlightReason = typeof ComboboxHighlightReason.Type

/**
 * How a `Combobox` matches its items against the text.
 *
 * **Details**
 *
 * - `"contains"`: the label contains the text
 * - `"startsWith"`: the label starts with it
 * - `"endsWith"`: the label ends with it
 * - `"none"`: every item is drawn, for a consumer that filters `items`
 *   itself
 *
 * Matching ignores case, accents and punctuation, in the `locale`.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxFilterMode = Engine.FilterMode

/**
 * How a `Combobox` matches its items against the text.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxFilterMode = typeof ComboboxFilterMode.Type

const propsSchema = <S extends Schema.Codec<string, string>>(value: S) => {
  const item = Engine.itemSchema(value)
  return Schema.Struct({
    open: Schema.Boolean,
    inputValue: Schema.String,
    items: Schema.Array(item),
    value: Schema.optional(valueSchema(value)),
    multiple: Schema.optional(Schema.Boolean),
    filter: Schema.optional(ComboboxFilterMode),
    filteredItems: Schema.optional(Schema.Array(item)),
    locale: Schema.optional(Schema.String),
    limit: Schema.optional(Schema.Number),
    autoHighlight: Schema.optional(Schema.Boolean),
    highlightItemOnHover: Schema.optional(Schema.Boolean),
    loopFocus: Schema.optional(Schema.Boolean),
    openOnInputClick: Schema.optional(Schema.Boolean),
    inputInPopup: Schema.optional(Schema.Boolean),
    inline: Schema.optional(Schema.Boolean),
    grid: Schema.optional(Schema.Boolean),
    virtualized: Schema.optional(Schema.Boolean),
    placeholder: Schema.optional(Schema.String),
    disabled: Schema.optional(Schema.Boolean),
    readOnly: Schema.optional(Schema.Boolean),
    required: Schema.optional(Schema.Boolean),
    name: Schema.optional(Schema.String),
    form: Schema.optional(Schema.String),
    autoComplete: Schema.optional(Schema.String),
    id: Schema.optional(Schema.String),
    dir: Schema.optional(Schema.Literals(["ltr", "rtl"])),
    modal: Schema.optional(Schema.Boolean),
    dismissLabel: Schema.optional(Schema.String),
    removedLabel: Schema.optional(Schema.String),
    finalFocus: Schema.optional(Schema.Boolean),
    holdExit: Schema.optional(Schema.Boolean),
    ...Positioning.PositionerFields
  })
}

/**
 * The props of a `Combobox`.
 *
 * **Details**
 *
 * - `open`: whether the popup shows. The combobox only asks, with
 *   `RequestedOpen` and `RequestedClose`.
 * - `inputValue`: the input's text. The combobox only asks, with
 *   `RequestedInputValue`.
 * - `items`: every option, in the order they're drawn.
 * - `value`: the selected value, or values with `multiple`. `null` when
 *   left out. The combobox only asks, with `Picked`.
 * - `multiple`: more than one item can be selected, and picking one
 *   leaves the popup open unless the text filtered the list. False when
 *   left out.
 * - `filter`: how the text matches the items. `"contains"` when left out.
 * - `filteredItems`: the items to draw, from the consumer's own filter,
 *   in place of `filter`.
 * - `locale`: the locale the filter compares in. The runtime's when left
 *   out.
 * - `limit`: the most items drawn. All of them when left out.
 * - `autoHighlight`: typing highlights the first match, so Enter picks
 *   it. False when left out.
 * - `highlightItemOnHover`: the pointer highlights the item it's over.
 *   True when left out.
 * - `loopFocus`: the arrow keys go past the ends of the list and around.
 *   True when left out.
 * - `openOnInputClick`: a press on the input opens the popup. True when
 *   left out.
 * - `inputInPopup`: the input is drawn inside the popup, and the trigger
 *   is the combobox. False when left out.
 * - `inline`: the list is drawn without a popup and is always expanded.
 *   False when left out.
 * - `grid`: the items are drawn in rows, by their `row`, and the list is
 *   a grid. False when left out.
 * - `virtualized`: the consumer draws only some of the items, so the
 *   combobox doesn't scroll the highlighted one into view; scroll to it on
 *   `Highlighted`. False when left out.
 * - `placeholder`: the `value` part's text while nothing is selected.
 * - `disabled`, `readOnly`, `required`: as on a native `<input>`.
 *   A read-only combobox opens and can be browsed but not changed.
 * - `name`, `form`, `autoComplete`: the form field.
 * - `id`: the input's id, or the trigger's with `inputInPopup`, unless
 *   the builder has one. Generated when left out.
 * - `dir`: the writing direction, for the horizontal arrow keys. When
 *   left out, the nearest `DirectionProvider`'s or, without one, the CSS
 *   `direction` of the chips for the chip keys, and of the popup or an
 *   inline list for the item keys.
 * - `modal`: while open, the page doesn't scroll and a press outside only
 *   closes the popup. With `inputInPopup`, the popup is also a modal
 *   dialog that Tab doesn't leave. False when left out.
 * - `dismissLabel`: the name of the visually hidden dismiss button in the
 *   popup. `"Dismiss"` when left out.
 * - `removedLabel`: announced after a chip's label once `value` drops
 *   it. `"removed"` when left out.
 * - `finalFocus`: with `inputInPopup`, on close, focus goes back to the
 *   trigger, or to a `finalFocus` part. False leaves it where it is. True
 *   when left out.
 * - `holdExit`: keeps the closing popup shown, for an exit animation the
 *   consumer ends by clearing it.
 * - the `Positioning.PositionerFields`, for the popup, `topLayer: false`
 *   among them to draw it in place, as the module describes. `side` is
 *   `"bottom"` when left out, and the anchor is the input group, or the
 *   input without one, or the trigger with `inputInPopup`.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxProps = propsSchema(Schema.String)

/**
 * The props of a `Combobox`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxProps<V extends string = string> = ReturnType<
  typeof propsSchema<Schema.Codec<V, string>>
>["Type"]

const eventsSchema = <S extends Schema.Codec<string, string>>(value: S) =>
  UiSchema.TaggedEnum({
    RequestedOpen: { reason: ComboboxChangeReason },
    RequestedClose: { reason: ComboboxChangeReason },
    Picked: { value: valueSchema(value), reason: ComboboxChangeReason },
    RequestedInputValue: {
      inputValue: Schema.String,
      reason: ComboboxChangeReason
    },
    Highlighted: {
      value: Schema.NullOr(value),
      index: Schema.Number,
      reason: ComboboxHighlightReason
    },
    Settled: { open: Schema.Boolean }
  })

/**
 * What a `Combobox` emits.
 *
 * **Details**
 *
 * - `RequestedOpen`: asks for `open` to be true.
 * - `RequestedClose`: asks for `open` to be false.
 * - `Picked`: asks for `value` to be `value`, the whole new selection.
 * - `RequestedInputValue`: asks for `inputValue` to be `inputValue`. A
 *   single pick asks for the picked label, and after the popup closes the
 *   combobox asks for the selected label back, or for empty text with
 *   `multiple` or `inputInPopup`.
 * - `Highlighted`: reports that the highlighted item changed, to `value` at
 *   `index` in `combobox.items`, or to none with `null` and `-1`. For a
 *   virtualized list to scroll to it.
 * - `Settled`: reports that the popup's transitions ended, after it
 *   opened or closed.
 *
 * @stability experimental
 * @category schemas
 * @since 0.1.0
 */
export const ComboboxEvents = eventsSchema(Schema.String)

/**
 * What a `Combobox` emits.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxEvents<V extends string = string> = ReturnType<
  typeof eventsSchema<Schema.Codec<V, string>>
>["Type"]

/**
 * Where a combobox's popup is in its transitions: `"starting"` for the
 * first frame after it opens, `"ending"` while it closes, `null`
 * otherwise.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type ComboboxTransitionStatus = Engine.TransitionStatus

/**
 * A run of items to draw under one group label: the items whose `group`
 * is `key`, in order, and the same items split into rows by their
 * `row`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface ComboboxGroup<V extends string = string>
  extends Engine.Group<V>
{}

/**
 * The matchers a `Combobox` filters with, for a consumer's own filter.
 *
 * **Details**
 *
 * Each takes an item's text and the query, and ignores case, accents and
 * punctuation. An empty query matches everything.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface ComboboxFilter extends TextFilter {}

/**
 * The `ComboboxFilter` for a locale, the runtime's when left out. It's
 * cached, so calling it for each render is cheap.
 *
 * **Example** (Filtering items the consumer fetched)
 *
 * ```ts
 * import { makeComboboxFilter } from "@effect/ui-kit"
 *
 * const filter = makeComboboxFilter("fr")
 * filter.startsWith("Éclair", "ecl") // true
 * ```
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const makeComboboxFilter = (
  locale?: string | undefined
): ComboboxFilter => textFilter(locale)

/**
 * Creates a combobox whose selected values, items, value-taking parts and
 * `Picked` and `Highlighted` events use the supplied string-valued schema.
 * Input text remains a `string`. Selections come from `items` or `value`;
 * autofill selects only a matching item.
 *
 * The schema must encode to a string. Create the component once at module
 * level: each call creates a new component. The existing `Combobox` export
 * uses `Schema.String`.
 *
 * **Example** (A combobox typed by a literal union)
 *
 * ```ts import.meta.vitest
 * import { UiSchema } from "@effect/ui"
 * import { Html, HtmlServer } from "@effect/ui/html"
 * import { makeCombobox } from "@effect/ui-kit"
 * import { Effect, Schema } from "effect"
 *
 * const Fruit = Schema.Literals(["apple", "pear"])
 * const FruitCombobox = makeCombobox({ value: Fruit })
 * const items = [{ value: "apple", label: "Apple" }, { value: "pear", label: "Pear" }] as const
 *
 * const Message = UiSchema.TaggedEnum({
 *   PickedFruit: { fruit: Schema.NullOr(Fruit) },
 *   Typed: { text: Schema.String }
 * })
 *
 * const Picker = Html.component({
 *   name: "Picker",
 *   model: Schema.Struct({ fruit: Schema.NullOr(Fruit), text: Schema.String }),
 *   message: Message
 * }).make({
 *   init: () => ({ fruit: "pear" as const, text: "Pear" }),
 *   update: {
 *     PickedFruit: ($, { fruit }) => $.evolve({ fruit }),
 *     Typed: ($, { text }) => $.evolve({ text })
 *   },
 *   view: (h, model) =>
 *     FruitCombobox(h, {
 *       props: { open: false, value: model.fruit, inputValue: model.text, items },
 *       onEmit: {
 *         // `value` is "apple" | "pear" | ReadonlyArray<"apple" | "pear"> | null
 *         Picked: ({ value }) => Message.PickedFruit({ fruit: typeof value === "string" ? value : null }),
 *         RequestedInputValue: ({ inputValue }) => Message.Typed({ text: inputValue }),
 *         RequestedOpen: () => undefined,
 *         RequestedClose: () => undefined,
 *         Highlighted: () => undefined,
 *         Settled: () => undefined
 *       },
 *       view: (combobox) => combobox.input(h.input.attr("aria-label", "Fruit"))
 *     })
 * })
 *
 * const { html } = await Effect.runPromise(HtmlServer.renderToHtml(Picker, {}))
 * if (!html.includes('value="Pear"')) throw new Error("the input doesn't show the label")
 * ```
 *
 * @stability experimental
 * @category components
 * @since 0.1.0
 */
export const makeCombobox = <V extends string>(
  options: { readonly value: Schema.Codec<V, string> }
) => {
  const events = eventsSchema(options.value)
  const emits: Engine.Emits<ComboboxEvents<V>, V> = {
    requestedOpen: (reason) => events.RequestedOpen({ reason }),
    requestedClose: (reason) => events.RequestedClose({ reason }),
    picked: (value, reason) => events.Picked({ value, reason }),
    edited: (inputValue, reason) =>
      events.RequestedInputValue({ inputValue, reason }),
    highlighted: (value, index, reason) =>
      events.Highlighted({ value, index, reason }),
    settled: (open) => events.Settled({ open })
  }
  const engine = Engine.make(
    "Combobox",
    (props: ComboboxProps<V>): Engine.Settings<ComboboxEvents<V>, V> => ({
      ...props,
      emits
    })
  )
  return Html.component({
    name: "Combobox",
    props: propsSchema(options.value),
    model: Engine.Model,
    message: Engine.Message,
    events,
    reads: {
      provider: { owner: DirectionProvider, optional: true }
    },
    restore: false
  }).make({
    init: Engine.init,
    update: engine.update,
    parts: engine.parts
  })
}

/**
 * A combobox: an input that filters a list of options as the user types.
 *
 * **Details**
 *
 * The parts also return plain values for markup that depends on them:
 * `open`, `mounted` (the popup shows, through its exit transition),
 * `transitionStatus`, `inline`, `selected` (the `value` prop, or
 * `null`), `selectedItems` (the selected values with their labels, for
 * chips), `placeholder` (nothing is selected), `disabled`, `readOnly`,
 * `required`, `multiple`, `side` and `align` (where the popup ended
 * up), `highlighted` (the value of the highlighted item), `openMethod`,
 * which is `null` once the popup closes, `items` (the filtered items to
 * draw), `groups` and `listEmpty`.
 *
 * Each part's attributes win over the ones the consumer set on the builder
 * before the part, including the ones a state leaves absent. Besides the
 * ones under **Data attributes** in the module docs, they are:
 *
 * - `input`: `role="combobox"`, `aria-expanded`, `aria-haspopup`
 *   (`"grid"` with `grid`, otherwise `"listbox"`), `aria-controls` and
 *   `aria-activedescendant` while the list can be navigated,
 *   `aria-autocomplete`, `aria-readonly`, `aria-required`, `readonly`,
 *   `disabled`, `value`, and `autocomplete="off"`, `spellcheck`,
 *   `autocorrect` and `autocapitalize`. Its `id` is the one already on
 *   the builder, as from `field.control`. Otherwise it's the `id` prop, or
 *   a generated one with `inputInPopup`.
 * - `trigger`: `type="button"`, `aria-expanded`, `aria-haspopup`
 *   (`"dialog"` with `inputInPopup`, else as on the input),
 *   `aria-controls` while open, `disabled`, and `tabindex="-1"` and a
 *   fallback `aria-label="Open popup"` without `inputInPopup`. With `inputInPopup` it takes focus and is a combobox
 *   as well as the input: `role="combobox"`, `aria-required`,
 *   `aria-readonly`, an `id`, the one on the builder or else the `id`
 *   prop, and `aria-labelledby` pointing at `label` when the builder has
 *   none.
 * - `inputGroup`: `role="group"`
 * - `clear`, `chipRemove`: `type="button"`, `tabindex="-1"`, `disabled`,
 *   and a fallback `aria-label="Clear"` or `aria-label="Remove"`. It's
 *   left out when the builder has a name or text children, and is a
 *   `title` when a child is a component, so text the component renders
 *   still wins
 * - `chips`: `role="toolbar"` while a value is selected, and a visually
 *   hidden `role="status"` that says which chip `value` lost last
 * - `chip`: `tabindex="-1"`, and `aria-keyshortcuts="Backspace Delete"`
 *   unless `disabled` or `readOnly`
 * - `label`: `id`
 * - `backdrop`, `positioner`: `role="presentation"` and
 *   `popover="manual"`
 * - `popup`: `id`, `tabindex="-1"` and `role="presentation"`, or with
 *   `inputInPopup` `role="dialog"`, `aria-modal` and `aria-labelledby`
 *   pointing at `label`
 * - `list`: `id`, `role="listbox"`, or `"grid"` with `grid`,
 *   `tabindex="-1"`, `aria-multiselectable`, `aria-readonly`, and
 *   `aria-labelledby` pointing at `label`
 * - `row`: `role="row"`
 * - `item`: `id`, `role="option"`, or `"gridcell"` with `grid`,
 *   `aria-selected`, `aria-disabled`
 * - `group`: `role="group"`, or `"rowgroup"` with `grid`, and
 *   `aria-labelledby` pointing at its `groupLabel`
 * - `groupLabel`: `id` and `aria-hidden="true"`
 * - `icon`, `arrow`, `itemIndicator`: `aria-hidden="true"`, and `id` on
 *   the arrow
 * - `separator`: `role="separator"`, `aria-orientation="horizontal"`
 * - `empty`, `status`: `role="status"`, `aria-live="polite"`,
 *   `aria-atomic="true"`
 *
 * A part adds the ids it lists in `aria-controls`, and a group's
 * `aria-labelledby`, to the consumer's. Other names are fallbacks, left
 * out when the builder has an `aria-label` or `aria-labelledby`. Except
 * with `inline`, or with `inputInPopup` and not `modal`, the positioner
 * also holds a visually hidden Dismiss button for screen readers.
 *
 * The parts handle these events on a layer of their own, so the
 * consumer's handlers for them still run:
 *
 * - `input`: `input`, `compositionend`, `keydown`, `keyup` and
 *   `mousedown`, and `focusin` and `focusout` with `inline`
 * - `trigger`: `mousedown`, `mouseup`, `click` and `keydown`
 * - `inputGroup`, `chips`: `mousedown`, and the chips' `keydown` through
 *   the mount on `chips`
 * - `clear`, `chipRemove`: `mousedown` and `click`
 * - `label`: `click`
 * - `item`: `mouseenter`, `mouseleave`, `mousedown`, `mouseup` and
 *   `click`
 *
 * They cancel the keys they handle, and the `mousedown` on the input
 * group, the chips, the clear and remove buttons, the trigger without
 * `inputInPopup` and the items, so focus stays in the input. The
 * positioner's mount places the popup and listens for presses and focus
 * outside it. The mounts on the positioner, the chips and an inline list
 * also read their CSS `direction`.
 *
 * It emits `RequestedOpen`, `RequestedClose`, `Picked`,
 * `RequestedInputValue`, `Highlighted` and `Settled`.
 *
 * History restore saves nothing of it: after Back, forward or a reload it
 * starts from `init`.
 *
 * @stability experimental
 * @category components
 * @since 0.1.0
 */
export const Combobox = makeCombobox({ value: Schema.String })
